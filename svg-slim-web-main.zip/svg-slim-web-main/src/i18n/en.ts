export const en = {
	mainNav: {
		index: '规则',
		language: '语言',
		plugin: '插件',
		other: '其它',
	},
};
