export const isExp = (s: string) => s.toLowerCase().includes('e');
