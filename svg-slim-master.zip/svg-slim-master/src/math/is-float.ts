export const isFloat = (s: string) => s.includes('.');
