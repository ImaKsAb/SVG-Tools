export const getShorter = (a: string, b: string) => a.length <= b.length ? a : b;
