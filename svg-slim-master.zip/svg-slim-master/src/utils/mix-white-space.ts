export const mixWhiteSpace = (str: string): string => str.replace(/\s+/g, ' ');
