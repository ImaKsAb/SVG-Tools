import { IMatrixFunc } from '../../typings';
import { commaWsp, numberPattern } from '../const/syntax';
import { parseNumberList } from '../utils/parse-numberlist';

const matrixSingle = `(translate|scale|rotate|skewX|skewY|matrix)\\s*\\(\\s*(${numberPattern}(?:${commaWsp}${numberPattern})*)\\s*\\)`;
const matrixReg = new RegExp(matrixSingle, 'gm');
const matrixFullReg = new RegExp(`^${matrixSingle}(?:${commaWsp}${matrixSingle})*$`, 'm');

const matrixValLen = 6;

export const parseMatrix = (str: string): IMatrixFunc[] => {
	const result: IMatrixFunc[] = [];

	// 首先全字匹配完整的字符串，不匹配的直接退出
	if (matrixFullReg.test(str.trim())) {
		// 重置正则匹配位置
		matrixReg.lastIndex = 0;

		let match = matrixReg.exec(str);
		while (match !== null) {
			const val = parseNumberList(match[2]);
			// 验证参数的个数是否合法，不合法的直接退出
			if (match[1] === 'translate' || match[1] === 'scale') {
				if (val.length > 2) {
					return [];
				}
			} else if (match[1] === 'matrix') {
				if (val.length !== matrixValLen) {
					return [];
				}
			} else if (match[1] === 'rotate') {
				if (val.length !== 1 && val.length !== 3) {
					return [];
				}
			} else {
				if (val.length !== 1) {
					return [];
				}
			}
			result.push({
				type: match[1] as IMatrixFunc['type'],
				val,
			});
			match = matrixReg.exec(str);
		}
	}
	return result;
};
