# rm-xml-decl

* Default configuration:
```json
{
	"rules": {
		"rm-xml-decl": true
	}
}
```
* Explanation:
	* Remove xml declaration
