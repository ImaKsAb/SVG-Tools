# rm-doctype

* Default configuration:
```json
{
	"rules": {
		"rm-doctype": true
	}
}
```
* Explanation:
	* Remove DOCTYPE declaration
