# rm-version

* Default configuration:
```json
{
	"rules": {
		"rm-version": true
	}
}
```
* Explanation:
	* Remove version attribute from svg element
