# shorten-style-tag

* Default configuration:
```json
{
	"rules": {
		"shorten-style-tag": true
	}
}
```
* Explanation:
	* Remove duplicate definitions
	* Combine duplicate selectors or duplicate style sheets
	* Remove style sheets that cannot hit any objects
