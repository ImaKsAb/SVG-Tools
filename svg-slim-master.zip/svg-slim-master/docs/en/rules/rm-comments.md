# rm-comments

* Default configuration:
```json
{
	"rules": {
		"rm-comments": true
	}
}
```
* Explanation:
	* Remove comment
