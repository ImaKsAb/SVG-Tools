# rm-doctype

* 默认配置：
```json
{
	"rules": {
		"rm-doctype": [true]
	}
}
```
* 说明：
	* 移除 DOCTYPE 声明
