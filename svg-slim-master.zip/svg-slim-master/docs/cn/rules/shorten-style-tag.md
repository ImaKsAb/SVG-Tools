# shorten-style-tag

* 默认配置：
```json
{
	"rules": {
		"shorten-style-tag": true
	}
}
```
* 说明：
	* 移除重复的定义
	* 合并重复的选择器或重复的样式表
	* 移除无法命中任何对象的样式表
