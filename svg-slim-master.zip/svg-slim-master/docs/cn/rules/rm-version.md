# rm-version

* 默认配置：
```json
{
	"rules": {
		"rm-version": true
	}
}
```
* 说明：
	* 移除 svg 元素的 version 属性
