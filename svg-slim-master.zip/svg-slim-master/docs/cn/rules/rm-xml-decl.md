# rm-xml-decl

* 默认配置：
```json
{
	"rules": {
		"rm-xml-decl": true
	}
}
```
* 说明：
	* 移除 xml 声明
