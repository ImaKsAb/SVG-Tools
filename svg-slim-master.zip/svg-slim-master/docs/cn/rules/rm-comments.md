# rm-comments

* 默认配置：
```json
{
	"rules": {
		"rm-comments": true
	}
}
```
* 说明：
	* 移除注释
